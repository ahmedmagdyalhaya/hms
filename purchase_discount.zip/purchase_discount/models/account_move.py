from odoo import api, fields, models




class Account_invoice_new(models.Model):
    _inherit = 'account.move.line'
    
    
    def account(self):
      for lines in self:
       if lines.product_id.product_tmpl_id.categ_id.property_stock_account_input_categ_id:

         for line in lines:
            line.write({'account_id':line.product_id.product_tmpl_id.categ_id.property_stock_account_input_categ_id.id})
   
    
   