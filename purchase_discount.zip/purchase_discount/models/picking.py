from odoo import fields , models , api


class stock_picking_lot(models.Model):
    _inherit = 'stock.move.line'

    expired_date = fields.Date(string="Expiration Date" ,compute="_compute_stock_lot")
    qty = fields.Float(string="Qty",compute="_compute_stock_lot")

    @api.depends('lot_id')
    def _compute_stock_lot(self):
        self.write({'expired_date': self.lot_id.expiration_date,
                    'qty': self.lot_id.product_qty}) 
