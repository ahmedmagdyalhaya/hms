# -*- coding: utf-8 -*-
{
    'name': "Purchase_Discount",



    'description': """
        Purchase discount modules 
    """,

    'author': "Alhayah Degital",


    
    'version': '0.1',

    'depends': ['base','purchase'],

    'data': [
        'security/purchase_approval.xml',

        'views/discount.xml',
        'views/picking.xml',
    ]
}
